# -*- coding: utf-8 -*-
"""
Created on Sat Jan 11 09:22:50 2025

@author: johnny.fu
"""

from datetime import datetime
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
from scipy.stats import norm
import warnings
import os
path = 'D:/杂/tw/'
os.chdir(path)
warnings.filterwarnings('ignore')
mpl.rcParams['font.sans-serif'] = [u'SimHei'] #

def info_split(x):
    return x[-1][0], x[-1][1], x[-1][2]

if __name__ == '__main__':
    filename_create = 'createrole_login_record.csv'
    filename_game = 'user_daily_session_length_record.csv'
    filename_pay = 'user_payment_record.csv'
    
    '读数据'
    data_create = pd.read_csv(f'Data/{filename_create}')
    data_game = pd.read_csv(f'Data/{filename_game}')
    data_pay = pd.read_csv(f'Data/{filename_pay}')
    # data = 
    
    '预处理'
    data_create = data_create[data_create.server_id>0]
    data_create.dt = pd.to_datetime(data_create.dt)
    data_create.time = data_create.time.apply(lambda x: datetime.fromtimestamp(x / 1000.0))
    data_game.dt = pd.to_datetime(data_game.dt)
    data_pay.date = pd.to_datetime(data_pay.date)
    
    '分析'
    '注册登陆'
    data_create.columns
    max(data_create.server_id.unique())
    len(data_create[data_create.server_id==2])
    create_time_first, create_time_last, len_serve = [], [], []
    login_times_daily, login_times_all = [], []
    create_times_daily, create_times_all = [], []
    create_login_times_daily, create_login_man_daily = [], []
    
    serve_id = sorted(data_create.server_id.unique())
    for s_id in serve_id:
        data_tmp = data_create[(data_create.server_id==s_id)]# & (data_create.type=='g_createrole')]
        data_tmp.sort_values('time', inplace=True)
        len_serve.append(len(data_tmp))
        create_time_first.append(data_tmp.time.iloc[0])
        create_time_last.append(data_tmp.time.iloc[-1])
        create_times_all.append(len(data_tmp[data_tmp.type=='g_createrole']))
        login_times_all.append(len(data_tmp[data_tmp.type=='g_login']))
        login_tmp, create_tmp, create_login_tmp, create_login_man_tmp = [], [], [], []
        for t in sorted(data_tmp.dt.unique()):
            login_tmp.append(len(data_tmp[(data_tmp.dt==t) & (data_tmp.type=='g_login')]))
            create_tmp.append(len(data_tmp[(data_tmp.dt==t)& (data_tmp.type=='g_createrole')]))
            create_login_tmp.append(len(data_tmp[data_tmp.dt==t]))
            create_login_man_tmp.append(len(data_tmp[data_tmp.dt==t].ctwid.unique()))
        login_times_daily.append(login_tmp)
        create_times_daily.append(create_tmp)
        create_login_times_daily.append(create_login_tmp)
        create_login_man_daily.append(create_login_man_tmp)
        
    for i in range(len(create_login_times_daily)):
        data_tmp = pd.DataFrame(create_login_times_daily[i], index=np.arange(len(create_login_times_daily[i])))
        data_tmp.plot()
        plt.ylabel('次数')
        plt.xlabel('开服天')
        plt.title('每天创建登陆次数')
        plt.savefig(f'分析/createlogin/times/每天创建登陆次数_{serve_id[i]}.png')
        data_tmp = pd.DataFrame(create_login_man_daily[i], index=np.arange(len(create_login_man_daily[i])))
        data_tmp.plot()
        plt.ylabel('人数')
        plt.xlabel('开服天')
        plt.title('每天创建登陆人数')
        plt.savefig(f'分析/createlogin/man/每天创建登陆人数_{serve_id[i]}.png')
    
    df_login = pd.pivot_table(data_create, index=[u'ctwid', u'server_id', u'dt'], values=[u'type'], aggfunc=[np.count_nonzero])
    df_login['tmp'] = df_login.index
    df_login['ctwid'] = df_login[['tmp']].apply(lambda x:x[0][0], axis=1)
    df_login['server_id'] = df_login[['tmp']].apply(lambda x:x[0][1], axis=1)
    df_login['dt'] = df_login[['tmp']].apply(lambda x:x[0][2], axis=1)
    df_login = df_login.iloc[:,[0,2,3,4]]
    df_login.columns = ['times', 'ctwid', 'server_id', 'dt']
    df_login.index = np.arange(len(df_login))
    df_login.sort_values(['server_id', 'dt'], inplace=True)
    times_max, times_sum = [], []
    for i in range(16):
        df_tmp = df_login[df_login.server_id==serve_id[i]]
        dtlist = df_tmp.dt.unique()[:10]
        df_tmp = df_tmp[df_tmp.dt.isin(dtlist)]
        df_t = pd.pivot_table(df_tmp, index=[u'dt'], values=[u'times'], aggfunc=[np.sum])
        times_max.append(df_t.max()[0])
        times_sum.append(df_t.sum()[0])
    pd.DataFrame(times_max).plot.box()
    pd.DataFrame(times_max).hist()
    pd.DataFrame(times_sum).plot.box()
    pd.DataFrame(times_sum).hist()
    
    
    '登陆时长'
    data_game.columns
    len(data_game.ctwid.unique())
    df = pd.pivot_table(data_game, index=[u'ctwid'], values=[u'session_length'], aggfunc=[np.sum, np.mean, np.count_nonzero])
    len(df[df[('count_nonzero', 'session_length')]>1])
    df = df[df[('count_nonzero', 'session_length')]>1]
    df.columns
    df.describe()
    len(df[df[('mean', 'session_length')]>100])
    df[('mean', 'session_length')].hist()
    df[('mean', 'session_length')].plot.box()
    df[('mean', 'session_length')].mean()
    df[('mean', 'session_length')].median()
    
    sns.set_palette("hls")
    #sns.set_style("whitegrid")
    plt.figure(dpi=120)
    sns.set(style='dark')
    sns.set_style("dark", {"axes.facecolor": "#e9f3ea"})
    g = sns.distplot(df[('mean', 'session_length')],
                     hist=True,
                     kde=True,  # 开启核密度曲线kernel density estimate (KDE)
                     kde_kws={'linestyle': '--', 'linewidth': '1', 'color': '#c72e29',
                              # 设置外框线属性
                              },
                     fit=norm,
                     color='#098154',
                     axlabel='登陆时长',  # 设置x轴标题
    
                     )
    
    plt.show()

    
    '付费'
    data_pay.describe()
    df_pay = pd.pivot_table(data_pay, index=[u'ctwid'], values=[u'pay_amt'], aggfunc=[np.sum, np.mean, np.count_nonzero])
    df_pay.describe()
    pay_times_daily, pay_amount_daily = [], []
    for s_id in serve_id:
        data_tmp = data_pay[(data_pay.server_id==s_id)]
        pay_times_tmp, pay_amount_tmp = [], []
        for t in sorted(data_tmp.date.unique()):
            pay_times_tmp.append(len(data_tmp[(data_tmp.date==t) & (data_tmp.pay_amt>0)]))
            pay_amount_tmp.append(data_tmp.loc[(data_tmp.date==t) & (data_tmp.pay_amt>0), 'pay_amt'].sum())
        pay_times_daily.append(pay_times_tmp)
        pay_amount_daily.append(pay_amount_tmp)
        
    for i in range(len(pay_times_daily)):
        data_tmp = pd.DataFrame(pay_times_daily[i], index=np.arange(len(pay_times_daily[i])))
        data_tmp.plot()
        plt.ylabel('次数')
        plt.xlabel('开服天')
        plt.title('每天付费次数')
        plt.savefig(f'分析/pay/times/每天付费次数_{serve_id[i]}.png')
        data_tmp = pd.DataFrame(pay_amount_daily[i], index=np.arange(len(pay_amount_daily[i])))
        data_tmp.plot()
        plt.ylabel('金额')
        plt.xlabel('开服天')
        plt.title('每天付费金额')
        plt.savefig(f'分析/pay/amount/每天付费金额_{serve_id[i]}.png')
    
    df_pay = pd.pivot_table(data_pay, index=[u'ctwid', u'server_id', u'date'], values=[u'pay_amt'], aggfunc=[np.sum, np.count_nonzero])
    df_pay['tmp'] = df_pay.index
    df_pay['ctwid'] = df_pay[['tmp']].apply(lambda x:x[0][0], axis=1)
    df_pay['server_id'] = df_pay[['tmp']].apply(lambda x:x[0][1], axis=1)
    df_pay['dt'] = df_pay[['tmp']].apply(lambda x:x[0][2], axis=1)
    df_pay = df_pay.iloc[:,[0,1,3,4,5]]
    df_pay.columns = ['msum', 'times', 'ctwid', 'server_id', 'dt']
    df_pay.index = np.arange(len(df_pay))
    df_pay.sort_values(['server_id', 'dt'], inplace=True)
    times_max, times_sum = [], []
    msum_max, msum_sum = [], []
    for i in range(16):
        df_tmp = df_pay[df_pay.server_id==serve_id[i]]
        dtlist = df_tmp.dt.unique()[:10]
        df_tmp = df_tmp[df_tmp.dt.isin(dtlist)]
        df_t = pd.pivot_table(df_tmp, index=[u'dt'], values=[u'times', u'msum'], aggfunc=[np.sum])
        times_max.append(df_t.max()[1])
        times_sum.append(df_t.sum()[1])
        msum_max.append(df_t.max()[0])
        msum_sum.append(df_t.sum()[0])
    pd.DataFrame(times_max).plot.box()
    pd.DataFrame(times_max).hist()
    pd.DataFrame(times_sum).plot.box()
    pd.DataFrame(times_sum).hist()
    pd.DataFrame(msum_max).plot.box()
    pd.DataFrame(msum_max).hist()
    pd.DataFrame(msum_sum).plot.box()
    pd.DataFrame(msum_sum).hist()
    
    df_login_pay = pd.DataFrame(index=np.arange(len(times_sum)))
    df_login_pay['times'] = times_sum
    df_login_pay['income'] = msum_sum
    df_login_pay.plot.scatter(x='times', y='income')
    df_login_pay.times.mean()
    df_login_pay.income.mean()
    
    '融合'
    df_all = data_create.copy()
    df_all['pay_thisserver'] = 0#前后历史都付钱
    df_all['paid_thisserver'] = 0#前历史付钱
    df_pay_daily = pd.pivot_table(data_pay, index=[u'ctwid', u'date', u'server_id'], values=[u'pay_amt'], aggfunc=[np.sum, np.mean, np.count_nonzero])
    df_pay_daily = df_pay_daily[df_pay_daily[('count_nonzero', 'pay_amt')]>0]
    df_pay_daily['tmp'] = df_pay_daily.index
    df_pay_daily['ctwid'] = df_pay_daily[['tmp']].apply(lambda x:x[0][0], axis=1)
    df_pay_daily['dt'] = df_pay_daily[['tmp']].apply(lambda x:x[0][1], axis=1)
    df_pay_daily['server_id'] = df_pay_daily[['tmp']].apply(lambda x:x[0][2], axis=1)
    # df_pay_daily[['ctwid', 'dt', 'server_id']] = zip(*df_pay_daily.apply(info_split, axis=1))
    # df_pay_daily.drop(df_pay_daily.columns[:3], inplace=True)
    df_pay_daily = df_pay_daily.iloc[:, 4:]
    df_pay_daily.columns = ['ctwid', 'dt', 'server_id']
    df_pay_daily.index = np.arange(len(df_pay_daily))
    df_pay_daily.sort_values(by=['server_id', 'dt'], inplace=True)
    for i in range(2044, len(df_pay_daily)):
        ctw_id = df_pay_daily.iloc[i, 0]
        date = df_pay_daily.iloc[i, 1]
        sv_id = df_pay_daily.iloc[i, 2]
        # df_all.loc[(df_all.ctwid==ctw_id) & (df_all.server_id==sv_id), 'pay_thisserver'] = 1
        df_all.loc[(df_all.ctwid==ctw_id) & (df_all.server_id==sv_id) & (df_all.dt>date), 'pay_thisserver'] = 1
        if i % 500 == 0:
            print(i)
    
    
    
    
    